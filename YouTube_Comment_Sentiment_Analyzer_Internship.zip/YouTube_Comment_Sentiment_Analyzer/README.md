# YouTube Comment Sentiment Analyzer
Sample internship project.
